# csound-vst

Michael Gogins<br>
https://github.com/gogins<br>
http://michaelgogins.tumblr.com

VST is a trademark of Steinberg Media Technologies GmbH.

## Introduction

CsoundVST enables Csound to run as a native VST plugin in VST hosts.

The vst4cs opcodes enable Csound itself to host native VST plugins.

Please note, a native VST plugin on Linux is one that runs as a regular 
Linux loadable module and does not require Wine or any "helper" software.

These binaries are built for 64 bit CPU architecture on Ubuntu 18.04 and 
require a current installation of Csound, API version 4, from 
https://github.com/csound/csound.github.io to run.

Please report issues or request enhancements by email to 
michael dot gogins at gmail dot com.

## Changes

Now installs as a Debian package.

Rebuilt with Csound 6.11.

## Installation

Download the package from https://michaelgogins.tumblr.com/csound_extended. 

In the terminal, execute `sudo apt install ./csound-vst-1.0.0-Linux.deb`.

Set your VST host search path to include /usr/lib/vst.

Set your Csound plugin search path (that is, the environment variable 
OPCODE6DIR64) to include /usr/lib/csound/plugins64-6.0. 

## Usage

### vst4cs

See /usr/share/doc/csound-vst/doc/index.html for the opcodes reference.

### CsoundVST

CsoundVST can run either as a VST effect or as a VST instrument. Use the 
checkbox to select the configuration, then click on the Apply button.

In order to produce sound, you must load a Csound .csd file containing 
Csound instruments into CsoundVST, and click on the Play button to compile 
and run the Csound orchestra. The /usr/share/doc/csound-vst/examples directory 
contains such a .csd file. Once you have a working orchestra, be sure to save 
it in your DAW file by saving it in a preset for CsoundVST.

## Source Code

All open source code used to build these binaries can be obtained from the 
csound repository at https://github.com/csound/csound.github.io, or the 
csound-extended repository at https://github.com/gogins/csound-extended.

The VST2 SDK from Steinberg was also used, with permission, to build these 
binaries. You can obtain the VST SDK from 
https://www.steinberg.net/en/company/developers.html.


