Audio samples are distributed under Creative Common Sampling Plus 1.0 License:
http://creativecommons.org/licenses/sampling+/1.0/legalcode
======================================================================

File:
	Name: "floortom1.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=45051
	Date of upload: 2007-12-17 12:05:09
	
Designer / Creator / Uploader:
	Name: "Matias.Reccius"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=428371
	
Description:
	By "Matias.Reccius" : X-Act heavy metal drum kit==========================Drum kit: Tama RockstarSnare: Mapex mapleCymbals: ZildjianAll were recorded in studio with a Sennheiser e835 microphone plugged into a Roland Juno-G synthesizer. Cymbals need some 15kHz EQ increase because of the dynamic microphone\'s treble roll-off. No copyrights, free for all uses.I recommend using Native Instruments Battery to launch the samples. Each of the Battery\'s cells can accept stacked multi-samples, and the kit can be played through an electronic drum kit through MIDI. Excellent results.Any comments, contact Matias: matias.reccius@gmail.com

Tags:
	drum floor heavy kit metal rockstar tama tom 
======================================================================
    
File:
	Name: "floortom4.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=45054
	Date of upload: 2007-12-17 12:05:17
	
Designer / Creator / Uploader:
	Name: "Matias.Reccius"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=428371
	
Description:
	By "Matias.Reccius" : X-Act heavy metal drum kit==========================Drum kit: Tama RockstarSnare: Mapex mapleCymbals: ZildjianAll were recorded in studio with a Sennheiser e835 microphone plugged into a Roland Juno-G synthesizer. Cymbals need some 15kHz EQ increase because of the dynamic microphone\'s treble roll-off. No copyrights, free for all uses.I recommend using Native Instruments Battery to launch the samples. Each of the Battery\'s cells can accept stacked multi-samples, and the kit can be played through an electronic drum kit through MIDI. Excellent results.Any comments, contact Matias: matias.reccius@gmail.com

Tags:
	drum floor heavy kit metal rockstar tama tom     
======================================================================

File:
	Name: "tom10_1.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=45082
	Date of upload: 2007-12-17 12:06:01
	
Designer / Creator / Uploader:
	Name: "Matias.Reccius"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=428371
	
Description:
	By "Matias.Reccius" : X-Act heavy metal drum kit==========================Drum kit: Tama RockstarSnare: Mapex mapleCymbals: ZildjianAll were recorded in studio with a Sennheiser e835 microphone plugged into a Roland Juno-G synthesizer. Cymbals need some 15kHz EQ increase because of the dynamic microphone\'s treble roll-off. No copyrights, free for all uses.I recommend using Native Instruments Battery to launch the samples. Each of the Battery\'s cells can accept stacked multi-samples, and the kit can be played through an electronic drum kit through MIDI. Excellent results.Any comments, contact Matias: matias.reccius@gmail.com

Tags:
	drum heavy kit metal rockstar tama tom 
======================================================================

File:
	Name: "tom10_5.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=45086
	Date of upload: 2007-12-17 12:06:05
	
Designer / Creator / Uploader:
	Name: "Matias.Reccius"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=428371
	
Description:
	By "Matias.Reccius" : X-Act heavy metal drum kit==========================Drum kit: Tama RockstarSnare: Mapex mapleCymbals: ZildjianAll were recorded in studio with a Sennheiser e835 microphone plugged into a Roland Juno-G synthesizer. Cymbals need some 15kHz EQ increase because of the dynamic microphone\'s treble roll-off. No copyrights, free for all uses.I recommend using Native Instruments Battery to launch the samples. Each of the Battery\'s cells can accept stacked multi-samples, and the kit can be played through an electronic drum kit through MIDI. Excellent results.Any comments, contact Matias: matias.reccius@gmail.com

Tags:
	drum heavy kit metal rockstar tama tom 
======================================================================

File:
	Name: "tom12_1.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=45087
	Date of upload: 2007-12-17 12:06:07
	
Designer / Creator / Uploader:
	Name: "Matias.Reccius"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=428371
	
Description:
	By "Matias.Reccius" : X-Act heavy metal drum kit==========================Drum kit: Tama RockstarSnare: Mapex mapleCymbals: ZildjianAll were recorded in studio with a Sennheiser e835 microphone plugged into a Roland Juno-G synthesizer. Cymbals need some 15kHz EQ increase because of the dynamic microphone\'s treble roll-off. No copyrights, free for all uses.I recommend using Native Instruments Battery to launch the samples. Each of the Battery\'s cells can accept stacked multi-samples, and the kit can be played through an electronic drum kit through MIDI. Excellent results.Any comments, contact Matias: matias.reccius@gmail.com

Tags:
	drum heavy kit metal rockstar tama tom 
======================================================================

File:
	Name: "tom12_4.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=45090
	Date of upload: 2007-12-17 12:06:13
	
Designer / Creator / Uploader:
	Name: "Matias.Reccius"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=428371
	
Description:
	By "Matias.Reccius" : X-Act heavy metal drum kit==========================Drum kit: Tama RockstarSnare: Mapex mapleCymbals: ZildjianAll were recorded in studio with a Sennheiser e835 microphone plugged into a Roland Juno-G synthesizer. Cymbals need some 15kHz EQ increase because of the dynamic microphone\'s treble roll-off. No copyrights, free for all uses.I recommend using Native Instruments Battery to launch the samples. Each of the Battery\'s cells can accept stacked multi-samples, and the kit can be played through an electronic drum kit through MIDI. Excellent results.Any comments, contact Matias: matias.reccius@gmail.com

Tags:
	drum heavy kit metal rockstar tama tom 
======================================================================

File:
	Name: "tom13_1.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=45091
	Date of upload: 2007-12-17 12:06:14
	
Designer / Creator / Uploader:
	Name: "Matias.Reccius"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=428371
	
Description:
	By "Matias.Reccius" : X-Act heavy metal drum kit==========================Drum kit: Tama RockstarSnare: Mapex mapleCymbals: ZildjianAll were recorded in studio with a Sennheiser e835 microphone plugged into a Roland Juno-G synthesizer. Cymbals need some 15kHz EQ increase because of the dynamic microphone\'s treble roll-off. No copyrights, free for all uses.I recommend using Native Instruments Battery to launch the samples. Each of the Battery\'s cells can accept stacked multi-samples, and the kit can be played through an electronic drum kit through MIDI. Excellent results.Any comments, contact Matias: matias.reccius@gmail.com

Tags:
	drum heavy kit metal rockstar tama tom 
======================================================================

File:
	Name: "tom13_4.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=45094
	Date of upload: 2007-12-17 12:06:18
	
Designer / Creator / Uploader:
	Name: "Matias.Reccius"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=428371
	
Description:
	By "Matias.Reccius" : X-Act heavy metal drum kit==========================Drum kit: Tama RockstarSnare: Mapex mapleCymbals: ZildjianAll were recorded in studio with a Sennheiser e835 microphone plugged into a Roland Juno-G synthesizer. Cymbals need some 15kHz EQ increase because of the dynamic microphone\'s treble roll-off. No copyrights, free for all uses.I recommend using Native Instruments Battery to launch the samples. Each of the Battery\'s cells can accept stacked multi-samples, and the kit can be played through an electronic drum kit through MIDI. Excellent results.Any comments, contact Matias: matias.reccius@gmail.com

Tags:
	drum heavy kit metal rockstar tama tom 
======================================================================

File:
	Name: "tom14_1.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=45095
	Date of upload: 2007-12-17 12:06:19
	
Designer / Creator / Uploader:
	Name: "Matias.Reccius"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=428371
	
Description:
	By "Matias.Reccius" : X-Act heavy metal drum kit==========================Drum kit: Tama RockstarSnare: Mapex mapleCymbals: ZildjianAll were recorded in studio with a Sennheiser e835 microphone plugged into a Roland Juno-G synthesizer. Cymbals need some 15kHz EQ increase because of the dynamic microphone\'s treble roll-off. No copyrights, free for all uses.I recommend using Native Instruments Battery to launch the samples. Each of the Battery\'s cells can accept stacked multi-samples, and the kit can be played through an electronic drum kit through MIDI. Excellent results.Any comments, contact Matias: matias.reccius@gmail.com

Tags:
	drum heavy kit metal rockstar tama tom 
======================================================================

File:
	Name: "tom14_4.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=45098
	Date of upload: 2007-12-17 12:06:23
	
Designer / Creator / Uploader:
	Name: "Matias.Reccius"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=428371
	
Description:
	By "Matias.Reccius" : X-Act heavy metal drum kit==========================Drum kit: Tama RockstarSnare: Mapex mapleCymbals: ZildjianAll were recorded in studio with a Sennheiser e835 microphone plugged into a Roland Juno-G synthesizer. Cymbals need some 15kHz EQ increase because of the dynamic microphone\'s treble roll-off. No copyrights, free for all uses.I recommend using Native Instruments Battery to launch the samples. Each of the Battery\'s cells can accept stacked multi-samples, and the kit can be played through an electronic drum kit through MIDI. Excellent results.Any comments, contact Matias: matias.reccius@gmail.com

Tags:
	drum heavy kit metal rockstar tama tom 
======================================================================

File:
	Name: "kick2-high-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16290
	Date of upload: 2006-02-27 17:32:25
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Kick Drum 22inch metal hard hit. My drum kit. Hohner rock drum kit with Aquarian Performance 2 heads and 14x6.5 Tama RockStar snare with Remo head. Sample is 24-bit, 44.1kHz recorded Feb 20, 2006.

Tags:
	22inch drum hard hit kick metal 
======================================================================

File:
	Name: "kick2-low-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16291
	Date of upload: 2006-02-27 17:32:25
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Kick Drum 22inch metal hard hit. My drum kit. Hohner rock drum kit with Aquarian Performance 2 heads and 14x6.5 Tama RockStar snare with Remo head. Sample is 24-bit, 44.1kHz recorded Feb 20, 2006.

Tags:
	22inch drum hit kick metal soft 
======================================================================

File:
	Name: "rim1-snare.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16292
	Date of upload: 2006-02-27 17:32:25
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Drum rim hit metal snare. My drum kit. Hohner rock drum kit with Aquarian Performance 2 heads and 14x6.5 Tama RockStar snare with Remo head. Sample is 24-bit, 44.1kHz recorded Feb 20, 2006.

Tags:
	drum hit metal rim snare 
======================================================================

File:
	Name: "sticks-high-pitch.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16296
	Date of upload: 2006-02-27 17:32:25
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Drum sticks high pitch. My drum kit. Hohner rock drum kit with Aquarian Performance 2 heads and 14x6.5 Tama RockStar snare with Remo head. Sample is 24-bit, 44.1kHz recorded Feb 20, 2006.

Tags:
	drum high pitch sticks 
======================================================================

File:
	Name: "sticks-low-pitch.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16297
	Date of upload: 2006-02-27 17:32:25
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Drum sticks low pitch. My drum kit. Hohner rock drum kit with Aquarian Performance 2 heads and 14x6.5 Tama RockStar snare with Remo head. Sample is 24-bit, 44.1kHz recorded Feb 20, 2006.

Tags:
	drum low pitch sticks 
======================================================================

File:
	Name: "snare-1-high-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16298
	Date of upload: 2006-02-27 17:32:25
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Drum Snare 14x6.5 hard hit. My drum kit. Hohner rock drum kit with Aquarian Performance 2 heads and 14x6.5 Tama RockStar snare with Remo head. Sample is 24-bit, 44.1kHz recorded Feb 20, 2006.

Tags:
	14x6 5 drum hard hit snare 
======================================================================

File:
	Name: "snare-1-low-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16299
	Date of upload: 2006-02-27 17:32:25
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Drum Snare 14x6.5 soft hit. My drum kit. Hohner rock drum kit with Aquarian Performance 2 heads and 14x6.5 Tama RockStar snare with Remo head. Sample is 24-bit, 44.1kHz recorded Feb 20, 2006.

Tags:
	14x6 5 drum hit snare soft 
======================================================================

File:
	Name: "snare-2-high-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16300
	Date of upload: 2006-02-27 17:32:25
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Drum Snare 14x6.5 hard hit. My drum kit. Hohner rock drum kit with Aquarian Performance 2 heads and 14x6.5 Tama RockStar snare with Remo head. Sample is 24-bit, 44.1kHz recorded Feb 20, 2006.

Tags:
	14x6 5 drum hard hit snare 
======================================================================

File:
	Name: "snare-2-low-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16301
	Date of upload: 2006-02-27 17:32:25
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Drum Snare 14x6.5  soft  hit. My drum kit. Hohner rock drum kit with Aquarian Performance 2 heads and 14x6.5 Tama RockStar snare with Remo head. Sample is 24-bit, 44.1kHz recorded Feb 20, 2006.

Tags:
	14x6 5 drum hit snare soft 
======================================================================

File:
	Name: "china-A-China-High-16-high-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16239
	Date of upload: 2006-02-27 17:31:06
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian A China High 16inch Cymbal hard hit. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	16inch a china cymbal high zildjian 
======================================================================

File:
	Name: "china-A-China-High-16-low-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16240
	Date of upload: 2006-02-27 17:31:07
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian A China High 16inch Cymbal soft hit. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	16inch a china cymbal high zildjian 
======================================================================

File:
	Name: "china-oriental-trash-18-high-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16243
	Date of upload: 2006-02-27 17:31:07
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian Oriental China Trash 18inch Cymbal hard hit. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	18inch china cymbal oriental trash zildjian 
======================================================================

File:
	Name: "china-oriental-trash-18-low-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16244
	Date of upload: 2006-02-27 17:31:41
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian Oriental China Trash 18inch Cymbal soft hit. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	18inch china cymbal oriental trash zildjian 
======================================================================

File:
	Name: "crash-A-custom-18-high-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16248
	Date of upload: 2006-02-27 17:31:41
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian A Custom  18inch Cymbal hard hit. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	18inch a custom cymbal zildjian 
======================================================================

File:
	Name: "crash-A-custom-18-low-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16249
	Date of upload: 2006-02-27 17:31:41
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian A Custom  18inch Cymbal soft hit. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	18inch a custom cymbal zildjian 
======================================================================

File:
	Name: "crash-A-medium-17-high-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16253
	Date of upload: 2006-02-27 17:31:41
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian A Medium 17inch Cymbal hard hit. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	17inch a cymbal medium zildjian 
======================================================================

File:
	Name: "crash-A-medium-17-low-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16254
	Date of upload: 2006-02-27 17:31:41
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : MZildjian A Medium 17inch Cymbal soft hit. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	17inch a cymbal medium zildjian 
======================================================================

File:
	Name: "crash-HHXplosion-18-high-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16258
	Date of upload: 2006-02-27 17:31:41
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Sabian HHXplosion 18inch Cymbal hard hit.My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	18inch cymbal hhxplosion sabian 
======================================================================

File:
	Name: "crash-HHXplosion-18-low-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16259
	Date of upload: 2006-02-27 17:31:55
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Sabian HHXplosion 18inch Cymbal soft hit. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	18inch cymbal hhxplosion sabian 
======================================================================

File:
	Name: "crash-Z-custom-projection-19-high-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16263
	Date of upload: 2006-02-27 17:31:55
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian Z Custom Projection 19inch Cymbal hard hit. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	19inch custom cymbal projection z zildjian 
======================================================================

File:
	Name: "crash-Z-custom-projection-19-low-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16264
	Date of upload: 2006-02-27 17:31:55
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian Z Custom Projection 19inch Cymbal soft hit. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	19inch custom cymbal projection z zildjian 
======================================================================

File:
	Name: "crash-Z-custom-projection-19-tip.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16265
	Date of upload: 2006-02-27 17:31:55
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian Z Custom Projection 19inch Cymbal bow hit using stick tip. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	19inch custom cymbal projection z zildjian 
======================================================================

File:
	Name: "HH-A-Custom-closed-hard.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16266
	Date of upload: 2006-02-27 17:31:55
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian A Custom Regular High Hat 14inch closed hard hit. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	14inch a custom hat high regular zildjian 
======================================================================

File:
	Name: "HH-A-Custom-closed-soft.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16267
	Date of upload: 2006-02-27 17:31:55
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian A Custom Regular High Hat 14inch closed soft hit. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	14inch a custom hat high regular zildjian 
======================================================================

File:
	Name: "HH-A-Custom-foot1.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16268
	Date of upload: 2006-02-27 17:31:55
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian A Custom Regular High Hat 14inch foot hit #1. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	14inch a custom hat high regular zildjian 
======================================================================

File:
	Name: "HH-A-Custom-foot2.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16269
	Date of upload: 2006-02-27 17:31:55
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian A Custom Regular High Hat 14inch foot hit #2. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	14inch a custom hat high regular zildjian 
======================================================================

File:
	Name: "HH-A-Custom-half-open-hard.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16273
	Date of upload: 2006-02-27 17:31:55
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian A Custom Regular High Hat 14inch 1/2 open hard hit. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	14inch a custom hat high regular zildjian 
======================================================================

File:
	Name: "HH-A-Custom-half-open-soft.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16274
	Date of upload: 2006-02-27 17:32:07
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian A Custom Regular High Hat 14inch 1/2 open soft hit. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	14inch a custom hat high regular zildjian 
======================================================================

File:
	Name: "ride-A-Ping-20-bell-2.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16277
	Date of upload: 2006-02-27 17:32:07
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian A Ping Ride 20inch bell hit #2.My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	20inch a bell hit ping ride zildjian 
======================================================================

File:
	Name: "ride-A-Ping-20-bell.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16278
	Date of upload: 2006-02-27 17:32:07
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian A Ping Ride 20inch bell hit #1. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	20inch a bell hit ping ride zildjian 
======================================================================

File:
	Name: "ride-A-Ping-20-bow1.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16279
	Date of upload: 2006-02-27 17:32:07
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian A Ping Ride 20inch bow hit #1. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	20inch a bow hit ping ride zildjian 
======================================================================

File:
	Name: "ride-A-Ping-20-bow2.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16280
	Date of upload: 2006-02-27 17:32:07
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian A Ping Ride 20inch bow hit #2. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	20inch a bow hit ping ride zildjian 
======================================================================

File:
	Name: "splash-A-custom-10-high-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16282
	Date of upload: 2006-02-27 17:32:07
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian A Custom Splash 10inch hard hit. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	10inch a custom hard hit splash zildjian 
======================================================================

File:
	Name: "splash-A-custom-10-low-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16283
	Date of upload: 2006-02-27 17:32:07
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian A Custom Splash 10inch soft hit. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	10inch a custom hit soft splash zildjian 
======================================================================

File:
	Name: "splash-zxt-flash-10-high-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16285
	Date of upload: 2006-02-27 17:32:07
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	10inch flash hard hit splash zildjian zxt 
======================================================================

File:
	Name: "splash-zxt-flash-10-low-vol.wav"
	Url: http://freesound.iua.upf.edu/samplesViewSingle.php?id=16286
	Date of upload: 2006-02-27 17:32:07
	
Designer / Creator / Uploader:
	Name: "ltibbits"
	Url: http://freesound.iua.upf.edu/usersViewSingle.php?id=49141
	
Description:
	By "ltibbits" : Zildjian ZXT Flash Splash 10inch soft hit. My personal cymbal collection. Sample is 24-bit 44.1kHz recorded with Alesis MultiMix 16 FireWire on Feb 20, 2006.

Tags:
	10inch flash hit soft splash zildjian zxt 
======================================================================

